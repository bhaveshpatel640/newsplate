<?php
error_reporting(0);
define("SMTP_HOST", "smtp.gmail.com"); //Hostname of the mail server
define("SMTP_PORT", "465"); //Port of the SMTP like to be 25, 80, 465 or 587
define("SMTP_UNAME", "newsplate2015@gmail.com"); //Username for SMTP authentication any valid email created in your domain
define("SMTP_PWORD", "wtproject"); //Password for SMTP authentication
?>