    <head>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.css"  media="screen,projection"/>
<!--        <link type="text/css" rel="stylesheet" href="css/bootstrap.css"  media="screen,projection"/>-->

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <style>
      body{
        overflow: auto;
        }
        .slider{
          -webkit-text-stroke:2px black;
    
        }
      .brand-logo{
        margin-left: 10px;
      }
        .dropdown-content{
            min-width:150px;
        }
        #dropdown2 li a{
          margin: 0;
          padding: 9px;
        }
    </style>
    </head>