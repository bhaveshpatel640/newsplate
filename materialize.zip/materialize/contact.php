<?php
  include "template/header.php";
?>
        <main>
            <div class="row">
                <div class="col s8 m8 l8 offset-m2 offset-s2 offset-l2">
          <div class="card" style="margin-top:5%";>
            <div class="card-content">
              <span class="card-title" style="color:black;">Contact Us</span>
                <li class="divider"></li>
                <p style="padding:3%;">E anim lorem o mentitum, cernantur multos et officia transferrem e eu irure 
                    eiusmod, eram mentitum id nescius, an ex sint quae elit, mentitum de noster 
                    vidisse, ab anim hic minim, qui illum quae non ingeniis. Fore consequat 
                    domesticarum hic admodum summis senserit mandaremus an ea occaecat 
                    comprehenderit eu eram quamquam ex exercitation sed officia elit arbitror ad 
                    excepteur duis malis aliquip aliqua, elit cernantur e enim minim, excepteur anim 
                    ut mentitum instituendarum. Est aliqua consequat quibusdam, cernantur non aute 
                    nostrud. Veniam hic possumus aut est eram tempor se a a quid quem malis de anim 
                    adipisicing offendit magna fabulas. Multos ut quibusdam ne mentitum noster eu 
                    commodo distinguantur. An fore singulis in singulis nulla irure tempor ipsum.</p>
            </div>
          </div>
        </div>
            </div>

<div style="width:877px; padding:20px; padding-top:20px; box-shadow:2px 2px 10px rgba(0,0,0,0.4);" class="container">

          <div class="row">
              <div class="col offset-m5">
                  <h5 class="grey-text center-align">Location</h5>
              </div>
          </div>
      <iframe src="http://www.map-generator.org/db92ce5e-3f31-4c5b-a0b0-86a83a77a024/iframe-map.aspx" scrolling="no" width="840px" height="400px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
      </iframe>
      <br>
    </div>
        </main>

         <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>
        <script>
        $(document).ready(function(){
    $('.collapsible').collapsible({
      accordion : false  // A setting that changes the collapsible behavior to expandable instead of the default accordion style
    });
  });
        </script>
        
    <?php include "template/footer.php"; ?>
  